import { Component, OnInit, OnDestroy } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../model/User';
import { Route, Router } from '@angular/router';
import { UserContextService } from '../services/UserContextService';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  username: string;
  password: string;
  user: User;
  isLoginUnSuccessful: boolean;
  constructor(private http:HttpClient, private route:Router, private userContextService:UserContextService) { }

  ngOnInit() {
  }

  login(){
    this.http.get<User>("/api/login?name="+this.username).subscribe(user => {
      this.user = user;
      if(this.user && this.user.password === this.password){
        this.userContextService.updateUser(this.user);
        this.route.navigate(["/home"]);
      } else {
        this.isLoginUnSuccessful = true;
      }
    });
  }

 

}
