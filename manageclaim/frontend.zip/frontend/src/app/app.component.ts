import { Component } from '@angular/core';
import { UserContextService } from './services/UserContextService';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  userName: string;
  constructor(private userContextService:UserContextService, private route:Router){
    this.userContextService.currentData.subscribe(user=>{
      this.userName = user != null ? user.name: null;
    });
  }
  login(){
    console.log('logging in');
  }

  logout(){
    this.userContextService.updateUser(null);
    this.route.navigate(["/home"]);
  }
}
