import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { ClaimsHomeComponent } from './claims-home/claims-home.component';
import { RouterModule, Router } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { AddclaimComponent } from './addclaim/addclaim.component';
import { ClaimsComponent } from './claims/claims.component';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    AppComponent,
    ClaimsHomeComponent,
    AddclaimComponent,
    ClaimsComponent
  ],
  imports: [
    BrowserModule,
    RouterModule,
    AppRoutingModule,
    NgbModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
