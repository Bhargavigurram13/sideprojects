import { Component, OnInit } from '@angular/core';
import { UserContextService } from '../services/UserContextService';
import { HttpClient } from '@angular/common/http';
import { Claim } from '../model/Claim';

@Component({
  selector: 'app-claims',
  templateUrl: './claims.component.html',
  styleUrls: ['./claims.component.css']
})
export class ClaimsComponent implements OnInit {

  userName:string;
  claims: Claim[];

  constructor(private userContextService:UserContextService, private http:HttpClient) { 
    this.userContextService.currentData.subscribe(user=>{
      this.userName = user != null ? user.name: null;
      if(user != null){
        this.http.get<Claim[]>("/api/claims?userid="+user.id).subscribe(claims => {
          this.claims = claims;
        });
      }
    });
  }

  ngOnInit() {
  }

}
