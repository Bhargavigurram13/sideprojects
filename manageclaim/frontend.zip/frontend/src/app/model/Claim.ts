export class Claim{
    anyOneInjured:string;
    noOfCars:number;
    emailaddress:string;
    claimDescription:string;
}