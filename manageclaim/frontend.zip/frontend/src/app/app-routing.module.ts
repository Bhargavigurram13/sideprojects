import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ClaimsHomeComponent } from './claims-home/claims-home.component';
import { AddclaimComponent } from './addclaim/addclaim.component';
import { ClaimsComponent } from './claims/claims.component';

const routes: Routes = [
    { path: 'home', component: ClaimsHomeComponent },
    { path: 'addclaim', component: AddclaimComponent },
    { path: 'claims', component: ClaimsComponent }
  ];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})


export class AppRoutingModule {}