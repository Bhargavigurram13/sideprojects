import { Component, OnInit } from '@angular/core';
import { Claim } from '../model/Claim';
import { UserContextService } from '../services/UserContextService';
import { User } from '../model/User';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-addclaim',
  templateUrl: './addclaim.component.html',
  styleUrls: ['./addclaim.component.css']
})
export class AddclaimComponent implements OnInit {
  claim:Claim = new Claim();
  userName:string;
  user:User;
  isClaimAdded:boolean;
  isClaimValidationFailed:boolean;
  constructor(private userContextService:UserContextService, private http:HttpClient) { 
    this.userContextService.currentData.subscribe(user=>{
      this.userName = user != null ? user.name: null;
      this.user = user;
    });
  }

  ngOnInit() {
  }

  addClaim(){
    if(this.claim.anyOneInjured){
      this.claim.userid =  this.user.id;
      this.claim.userName = this.user.name;
      console.log('claim:'+this.claim);
      this.http.post("/api/claims",this.claim).subscribe(resp => {
        this.isClaimAdded = true;
        this.isClaimValidationFailed = false;
      }, err=>{
        this.isClaimValidationFailed = true;
      });
    } else {
      this.isClaimValidationFailed = true;
    }
   
  }

}
