import { Component, OnInit } from '@angular/core';
import { Claim } from '../model/Claim';

@Component({
  selector: 'app-addclaim',
  templateUrl: './addclaim.component.html',
  styleUrls: ['./addclaim.component.css']
})
export class AddclaimComponent implements OnInit {
  claim:Claim = new Claim();

  constructor() { }

  ngOnInit() {
  }

  addClaim(){
    console.log('claim:'+this.claim);
  }

}
