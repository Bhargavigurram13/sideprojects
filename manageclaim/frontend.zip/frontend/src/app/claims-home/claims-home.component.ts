import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-claims-home',
  templateUrl: './claims-home.component.html',
  styleUrls: ['./claims-home.component.css']
})
export class ClaimsHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
