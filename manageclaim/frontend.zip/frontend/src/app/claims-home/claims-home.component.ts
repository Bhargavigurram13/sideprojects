import { Component, OnInit } from '@angular/core';
import { UserContextService } from '../services/UserContextService';

@Component({
  selector: 'app-claims-home',
  templateUrl: './claims-home.component.html',
  styleUrls: ['./claims-home.component.css']
})
export class ClaimsHomeComponent implements OnInit {
  userName:string;
  constructor(private userContextService:UserContextService) { 
    this.userContextService.currentData.subscribe(user=>{
      this.userName = user != null ? user.name: null;
    });
  }

  ngOnInit() {
  }

}
