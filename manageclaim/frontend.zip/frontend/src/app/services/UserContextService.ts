import { Injectable } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { User } from "../model/User";

@Injectable()
export class UserContextService {
    private data = new BehaviorSubject(new User());
    currentData = this.data.asObservable();

    updateUser(item: any) {
        this.data.next(item);
        sessionStorage.setItem('loggedInUser',JSON.stringify(item));
    }

}